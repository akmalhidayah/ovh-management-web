<?php

namespace App\Support\QcTemplates\Presets;

use App\Support\QcTemplates\PresetBlocks;

class WearSegmentRollerTorsiBautTemplate
{
    public static function data(): array
    {
        $meta = [
            'equipment' => 'Wear Segment Roller',
            'pekerjaan' => 'Penggantian Torsi Baut',
        ];

        return [
            'code' => 'QCR-WSR-TB-001',
            'number' => '21',
            'name' => 'Standard QCR Penggantian Wear Segment Roller; Torsi Baut',
            'category' => 'Wear Segment Roller',
            'version' => '1.0',
            'status' => 'draft',
            'layout_mode' => 'block_based',
            'meta' => $meta,
            'blocks' => PresetBlocks::make($meta, []),
        ];
    }
}
