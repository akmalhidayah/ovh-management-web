<?php

namespace App\Support\QcTemplates\Presets;

use App\Support\QcTemplates\PresetBlocks;

class GrateCoolerInstrumentFieldCrossbarTemplate
{
    public static function data(): array
    {
        $meta = [
            'equipment' => 'Grate Cooler',
            'pekerjaan' => 'Inspeksi Instrument Field Crossbar',
        ];

        return [
            'code' => 'QCR-GC-IFC-001',
            'number' => '23',
            'name' => 'Standard QCR Inspeksi Grate Cooler; Instrument Field Crossbar',
            'category' => 'Grate Cooler',
            'version' => '1.0',
            'status' => 'draft',
            'layout_mode' => 'block_based',
            'meta' => $meta,
            'blocks' => PresetBlocks::make($meta, []),
        ];
    }
}
