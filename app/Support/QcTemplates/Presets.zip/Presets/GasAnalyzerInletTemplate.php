<?php

namespace App\Support\QcTemplates\Presets;

use App\Support\QcTemplates\PresetBlocks;

class GasAnalyzerInletTemplate
{
    public static function data(): array
    {
        $meta = [
            'equipment' => 'Gas Analyzer',
            'pekerjaan' => 'Inspeksi Inlet',
        ];

        return [
            'code' => 'QCR-GA-INLET-001',
            'number' => '26',
            'name' => 'Standard QCR Inspeksi Gas Analyzer; Inlet',
            'category' => 'Gas Analyzer',
            'version' => '1.0',
            'status' => 'draft',
            'layout_mode' => 'block_based',
            'meta' => $meta,
            'blocks' => PresetBlocks::make($meta, []),
        ];
    }
}
