<?php

namespace App\Support\QcTemplates\Presets;

use App\Support\QcTemplates\PresetBlocks;

class SeparatorAtoxGuideVaneTemplate
{
    public static function data(): array
    {
        $meta = [
            'equipment' => 'Separator Atox Mill',
            'pekerjaan' => 'Inspeksi Guide Vane Separator',
        ];

        return [
            'code' => 'QCR-SAM-GVS-001',
            'number' => '10',
            'name' => 'Standard QCR Inspeksi Separator Atox Mill; Guide Vane Separator',
            'category' => 'Separator',
            'version' => '1.0',
            'status' => 'draft',
            'layout_mode' => 'block_based',
            'meta' => $meta,
            'blocks' => PresetBlocks::make($meta, []),
        ];
    }
}
