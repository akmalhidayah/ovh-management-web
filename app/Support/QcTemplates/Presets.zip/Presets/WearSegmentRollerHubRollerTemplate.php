<?php

namespace App\Support\QcTemplates\Presets;

use App\Support\QcTemplates\PresetBlocks;

class WearSegmentRollerHubRollerTemplate
{
    public static function data(): array
    {
        $meta = [
            'equipment' => 'Wear Segment Roller',
            'pekerjaan' => 'Penggantian Hub Roller',
        ];

        return [
            'code' => 'QCR-WSR-HR-001',
            'number' => '20',
            'name' => 'Standard QCR Penggantian Wear Segment Roller; Hub Roller',
            'category' => 'Wear Segment Roller',
            'version' => '1.0',
            'status' => 'draft',
            'layout_mode' => 'block_based',
            'meta' => $meta,
            'blocks' => PresetBlocks::make($meta, []),
        ];
    }
}
