<?php

namespace App\Support\QcTemplates\Presets;

use App\Support\QcTemplates\PresetBlocks;

class RotaryKilnCastableCastingBurnerGunTemplate
{
    public static function data(): array
    {
        $meta = [
            'equipment' => 'Rotary Kiln',
            'pekerjaan' => 'Penggantian Castable Casting Burner Gun',
        ];

        return [
            'code' => 'QCR-RK-CCBG-001',
            'number' => '13',
            'name' => 'Standard QCR Penggantian Rotary Kiln; Castable Casting Burner gun',
            'category' => 'Rotary Kiln',
            'version' => '1.0',
            'status' => 'draft',
            'layout_mode' => 'block_based',
            'meta' => $meta,
            'blocks' => PresetBlocks::make($meta, []),
        ];
    }
}
