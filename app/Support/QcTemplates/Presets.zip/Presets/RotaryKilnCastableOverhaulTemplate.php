<?php

namespace App\Support\QcTemplates\Presets;

use App\Support\QcTemplates\PresetBlocks;

class RotaryKilnCastableOverhaulTemplate
{
    public static function data(): array
    {
        $meta = [
            'equipment' => 'Rotary Kiln',
            'pekerjaan' => 'Penggantian Castable Overhaul',
        ];

        return [
            'code' => 'QCR-RK-CO-001',
            'number' => '14',
            'name' => 'Standard QCR Penggantian Rotary Kiln; Castable Overhaul',
            'category' => 'Rotary Kiln',
            'version' => '1.0',
            'status' => 'draft',
            'layout_mode' => 'block_based',
            'meta' => $meta,
            'blocks' => PresetBlocks::make($meta, []),
        ];
    }
}
