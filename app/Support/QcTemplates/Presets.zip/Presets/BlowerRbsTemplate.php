<?php

namespace App\Support\QcTemplates\Presets;

use App\Support\QcTemplates\PresetBlocks;

class BlowerRbsTemplate
{
    public static function data(): array
    {
        $meta = [
            'equipment' => 'Blower RBS 126 & RBS 155',
            'pekerjaan' => 'Inspeksi Blower RBS 126 & RBS 155',
        ];

        return [
            'code' => 'QCR-BRBS-001',
            'number' => '11',
            'name' => 'Standard QCR Inspeksi Blower RBS 126 & RBS 155',
            'category' => 'Blower',
            'version' => '1.0',
            'status' => 'draft',
            'layout_mode' => 'block_based',
            'meta' => $meta,
            'blocks' => PresetBlocks::make($meta, []),
        ];
    }
}
