<?php

namespace App\Support\QcTemplates\Presets;

use App\Support\QcTemplates\PresetBlocks;

class EspGrateCoolerDindingTemplate
{
    public static function data(): array
    {
        $meta = [
            'equipment' => 'ESP Grate Cooler',
            'pekerjaan' => 'Penggantian Dinding',
        ];

        return [
            'code' => 'QCR-ESP-GC-D-001',
            'number' => '34',
            'name' => 'Standard QCR Penggantian ESP Grate Cooler; Dinding',
            'category' => 'ESP Grate Cooler',
            'version' => '1.0',
            'status' => 'draft',
            'layout_mode' => 'block_based',
            'meta' => $meta,
            'blocks' => PresetBlocks::make($meta, []),
        ];
    }
}
