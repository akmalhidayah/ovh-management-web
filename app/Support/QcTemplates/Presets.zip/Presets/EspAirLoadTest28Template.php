<?php

namespace App\Support\QcTemplates\Presets;

use App\Support\QcTemplates\PresetBlocks;

class EspAirLoadTest28Template
{
    public static function data(): array
    {
        $meta = [
            'equipment' => 'ESP',
            'pekerjaan' => 'Inspeksi Air Load Test',
        ];

        return [
            'code' => 'QCR-ESP-ALT-028',
            'number' => '28',
            'name' => 'Standard QCR Inspeksi ESP; Air Load Test',
            'category' => 'ESP',
            'version' => '1.0',
            'status' => 'draft',
            'layout_mode' => 'block_based',
            'meta' => $meta,
            'blocks' => PresetBlocks::make($meta, []),
        ];
    }
}
