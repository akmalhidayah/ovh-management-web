<?php

namespace App\Support\QcTemplates\Presets;

use App\Support\QcTemplates\PresetBlocks;

class MbfCoalMillDindingTemplate
{
    public static function data(): array
    {
        $meta = [
            'equipment' => 'MBF Coal Mill',
            'pekerjaan' => 'Penggantian Dinding',
        ];

        return [
            'code' => 'QCR-MBF-CM-D-001',
            'number' => '33',
            'name' => 'Standard QCR Penggantian MBF Coal Mill; Dinding',
            'category' => 'MBF Coal Mill',
            'version' => '1.0',
            'status' => 'draft',
            'layout_mode' => 'block_based',
            'meta' => $meta,
            'blocks' => PresetBlocks::make($meta, []),
        ];
    }
}
