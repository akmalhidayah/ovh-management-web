<?php

namespace App\Support\QcTemplates\Presets;

use App\Support\QcTemplates\PresetBlocks;

class KilnFeedInstrumentFieldTemplate
{
    public static function data(): array
    {
        $meta = [
            'equipment' => 'Kiln Feed',
            'pekerjaan' => 'Inspeksi Instrument Field',
        ];

        return [
            'code' => 'QCR-KF-IF-001',
            'number' => '24',
            'name' => 'Standard QCR Inspeksi Kiln Feed; Instrument Field',
            'category' => 'Kiln Feed',
            'version' => '1.0',
            'status' => 'draft',
            'layout_mode' => 'block_based',
            'meta' => $meta,
            'blocks' => PresetBlocks::make($meta, []),
        ];
    }
}
