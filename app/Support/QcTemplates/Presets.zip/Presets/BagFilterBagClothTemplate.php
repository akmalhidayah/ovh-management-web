<?php

namespace App\Support\QcTemplates\Presets;

use App\Support\QcTemplates\PresetBlocks;

class BagFilterBagClothTemplate
{
    public static function data(): array
    {
        $meta = [
            'equipment' => 'Bag Filter',
            'pekerjaan' => 'Penggantian Bag Cloth',
        ];

        return [
            'code' => 'QCR-BF-BC-001',
            'number' => '32',
            'name' => 'Standard QCR Penggantian Bag Filter; Bag Cloth',
            'category' => 'Bag Filter',
            'version' => '1.0',
            'status' => 'draft',
            'layout_mode' => 'block_based',
            'meta' => $meta,
            'blocks' => PresetBlocks::make($meta, []),
        ];
    }
}
