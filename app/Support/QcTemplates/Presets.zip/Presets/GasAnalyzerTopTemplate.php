<?php

namespace App\Support\QcTemplates\Presets;

use App\Support\QcTemplates\PresetBlocks;

class GasAnalyzerTopTemplate
{
    public static function data(): array
    {
        $meta = [
            'equipment' => 'Gas Analyzer',
            'pekerjaan' => 'Inspeksi Top',
        ];

        return [
            'code' => 'QCR-GA-TOP-001',
            'number' => '27',
            'name' => 'Standard QCR Inspeksi Gas Analyzer; Top',
            'category' => 'Gas Analyzer',
            'version' => '1.0',
            'status' => 'draft',
            'layout_mode' => 'block_based',
            'meta' => $meta,
            'blocks' => PresetBlocks::make($meta, []),
        ];
    }
}
