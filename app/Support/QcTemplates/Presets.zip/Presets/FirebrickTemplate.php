<?php

namespace App\Support\QcTemplates\Presets;

use App\Support\QcTemplates\PresetBlocks;

class FirebrickTemplate
{
    public static function data(): array
    {
        $meta = [
            'equipment' => 'Firebrick',
            'pekerjaan' => 'Penggantian Firebrick',
        ];

        return [
            'code' => 'QCR-FB-001',
            'number' => '12',
            'name' => 'Standard QCR Penggantian Firebrick',
            'category' => 'Kiln',
            'version' => '1.0',
            'status' => 'draft',
            'layout_mode' => 'block_based',
            'meta' => $meta,
            'blocks' => PresetBlocks::make($meta, []),
        ];
    }
}
