<?php

namespace App\Support\QcTemplates\Presets;

use App\Support\QcTemplates\PresetBlocks;

class EspTeganganTembusInnerPartRawMillTemplate
{
    public static function data(): array
    {
        $meta = [
            'equipment' => 'ESP Raw Mill 533EP01',
            'pekerjaan' => 'Test Tegangan Tembus Inner Part Raw Mill 533EP01',
        ];

        return [
            'code' => 'QCR-ESP-TT-RM533EP01-001',
            'number' => '30',
            'name' => 'Standard QCR Inspeksi ESP; Test Tegangan Tembus Inner Part Raw Mill 533EP01',
            'category' => 'ESP',
            'version' => '1.0',
            'status' => 'draft',
            'layout_mode' => 'block_based',
            'meta' => $meta,
            'blocks' => PresetBlocks::make($meta, []),
        ];
    }
}
