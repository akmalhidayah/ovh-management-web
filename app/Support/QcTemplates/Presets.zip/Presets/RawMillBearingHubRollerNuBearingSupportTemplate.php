<?php

namespace App\Support\QcTemplates\Presets;

use App\Support\QcTemplates\PresetBlocks;

class RawMillBearingHubRollerNuBearingSupportTemplate
{
    public static function data(): array
    {
        $meta = [
            'equipment' => 'Raw Mill',
            'pekerjaan' => 'Penggantian Bearing ke Hub Roller NU Bearing & Support',
        ];

        return [
            'code' => 'QCR-RM-BHRNBS-001',
            'number' => '17',
            'name' => 'Standard QCR Penggantian Raw Mill; Bearing ke Hub Roller NU Bearing & Support',
            'category' => 'Raw Mill',
            'version' => '1.0',
            'status' => 'draft',
            'layout_mode' => 'block_based',
            'meta' => $meta,
            'blocks' => PresetBlocks::make($meta, []),
        ];
    }
}
