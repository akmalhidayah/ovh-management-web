<?php

namespace App\Support\QcTemplates\Presets;

use App\Support\QcTemplates\PresetBlocks;

class RawMillMaagGearInnerPartGearBox15Template
{
    public static function data(): array
    {
        $meta = [
            'equipment' => 'Maag Gear WPU-302',
            'pekerjaan' => 'Inspeksi Inner Part Gear Box',
        ];

        return [
            'code' => 'QCR-RM-WPU302-IPGB-015',
            'number' => '15',
            'name' => 'Standard QCR Inspeksi Raw Mill; Maag Gear WPU-302; Inner Part Gear Box',
            'category' => 'Raw Mill',
            'version' => '1.0',
            'status' => 'draft',
            'layout_mode' => 'block_based',
            'meta' => $meta,
            'blocks' => PresetBlocks::make($meta, []),
        ];
    }
}
