<?php

namespace App\Support\QcTemplates\Presets;

use App\Support\QcTemplates\PresetBlocks;

class CoalFeederRotorTemplate
{
    public static function data(): array
    {
        $meta = [
            'equipment' => 'Coal Feeder',
            'pekerjaan' => 'Inspeksi Rotor',
        ];

        return [
            'code' => 'QCR-CF-RTR-001',
            'number' => '25',
            'name' => 'Standard QCR Inspeksi Coal Feeder; Rotor',
            'category' => 'Coal Feeder',
            'version' => '1.0',
            'status' => 'draft',
            'layout_mode' => 'block_based',
            'meta' => $meta,
            'blocks' => PresetBlocks::make($meta, []),
        ];
    }
}
