<?php

namespace App\Support\QcTemplates\Presets;

use App\Support\QcTemplates\PresetBlocks;

class InnerPartEp02Template
{
    public static function data(): array
    {
        $meta = [
            'equipment' => 'Inner Part EP02',
            'pekerjaan' => 'Inspeksi Inner Part EP02',
        ];

        return [
            'code' => 'QCR-IP-EP02-001',
            'number' => '31',
            'name' => 'Standard QCR Inspeksi Inner Part EP02',
            'category' => 'ESP',
            'version' => '1.0',
            'status' => 'draft',
            'layout_mode' => 'block_based',
            'meta' => $meta,
            'blocks' => PresetBlocks::make($meta, []),
        ];
    }
}
