<?php

namespace App\Support\QcTemplates\Presets;

use App\Support\QcTemplates\PresetBlocks;

class WearingTyreKilnTemplate
{
    public static function data(): array
    {
        $meta = [
            'equipment' => 'Wearing Tyre Kiln',
            'pekerjaan' => 'Penggantian Wearing Tyre Kiln',
        ];

        return [
            'code' => 'QCR-WTK-001',
            'number' => '09',
            'name' => 'Standard QCR Penggantian Wearing Tyre Kiln',
            'category' => 'Kiln',
            'version' => '1.0',
            'status' => 'draft',
            'layout_mode' => 'block_based',
            'meta' => $meta,
            'blocks' => PresetBlocks::make($meta, []),
        ];
    }
}
