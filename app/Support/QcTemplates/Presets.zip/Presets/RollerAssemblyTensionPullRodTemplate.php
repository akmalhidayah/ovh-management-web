<?php

namespace App\Support\QcTemplates\Presets;

use App\Support\QcTemplates\PresetBlocks;

class RollerAssemblyTensionPullRodTemplate
{
    public static function data(): array
    {
        $meta = [
            'equipment' => 'Roller Assembly',
            'pekerjaan' => 'Penggantian Tension Pull Rod',
        ];

        return [
            'code' => 'QCR-RA-TPR-001',
            'number' => '19',
            'name' => 'Standard QCR Penggantian Roller Assembly; Tension Pull Rod',
            'category' => 'Roller Assembly',
            'version' => '1.0',
            'status' => 'draft',
            'layout_mode' => 'block_based',
            'meta' => $meta,
            'blocks' => PresetBlocks::make($meta, []),
        ];
    }
}
