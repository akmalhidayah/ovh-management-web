<?php

namespace App\Support\QcTemplates\Presets;

use App\Support\QcTemplates\PresetBlocks;

class RollerAssemblyRoller1CenterPieceTemplate
{
    public static function data(): array
    {
        $meta = [
            'equipment' => 'Roller Assembly',
            'pekerjaan' => 'Penggantian Roller 1 ke Center Piece',
        ];

        return [
            'code' => 'QCR-RA-R1CP-001',
            'number' => '18',
            'name' => 'Standard QCR Penggantian Roller Assembly; Roller 1 ke Center Piece',
            'category' => 'Roller Assembly',
            'version' => '1.0',
            'status' => 'draft',
            'layout_mode' => 'block_based',
            'meta' => $meta,
            'blocks' => PresetBlocks::make($meta, []),
        ];
    }
}
